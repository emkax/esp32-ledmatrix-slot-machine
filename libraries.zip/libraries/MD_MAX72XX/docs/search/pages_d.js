var searchData=
[
  ['the_20library_0',['Support the Library',['../page_donation.html',1,'index']]],
  ['types_1',['New Hardware Types',['../page_new_hardware.html',1,'pageHardware']]]
];
