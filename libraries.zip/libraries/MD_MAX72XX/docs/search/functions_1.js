var searchData=
[
  ['clear_0',['clear',['../class_m_d___m_a_x72_x_x.html#a5ce5b733333d776ef94e0cc36e1043cf',1,'MD_MAX72XX::clear(void)'],['../class_m_d___m_a_x72_x_x.html#ac57b7cd49a465e7f5f3027a1eac46242',1,'MD_MAX72XX::clear(uint8_t startDev, uint8_t endDev)'],['../class_m_d___m_a_x72_x_x.html#acff691690cb5848980f10be9facbe086',1,'MD_MAX72XX::clear(uint8_t buf)']]],
  ['control_1',['control',['../class_m_d___m_a_x72_x_x.html#aa54ba8b079710f6b4e9f9721e2e09c68',1,'MD_MAX72XX::control(uint8_t dev, controlRequest_t mode, int value)'],['../class_m_d___m_a_x72_x_x.html#aeb43fa0c917e716b9d35eac72fb1dd45',1,'MD_MAX72XX::control(controlRequest_t mode, int value)'],['../class_m_d___m_a_x72_x_x.html#aa724a797235e28a43b8d127e4999537e',1,'MD_MAX72XX::control(uint8_t startDev, uint8_t endDev, controlRequest_t mode, int value)']]]
];
